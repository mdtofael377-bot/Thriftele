# Thirftela (Static version)

Simple static single-page Thirftela website built with HTML/CSS/JS. No backend required. You can upload this to GitHub and deploy to Vercel/Netlify directly as a static site.

## How to use
- Open `index.html` locally to preview.
- Edit products inside `script.js` (PRODUCTS array).

## Contents
- index.html
- styles.css
- script.js
- README.md

This version simulates payments (bKash and Card) and does not process real transactions. For real payments, you'll need a server-side gateway integration (Stripe, bKash APIs, etc.).

Good luck with Thirftela!