// Simple static Thirftela shop (no backend).
// Products can be edited below.
const PRODUCTS = [
  {id:'p1', title:"Men's Casual Shirt", description:'100% cotton, well-preserved thrifted shirt. Size: L.', price:450, image:'https://picsum.photos/seed/shirt1/600/400', stock:5},
  {id:'p2', title:"Women's Kurti", description:'Traditional kurti, light wear, vibrant print. Size: M.', price:550, image:'https://picsum.photos/seed/kurti1/600/400', stock:3},
  {id:'p3', title:'Denim Jeans (Unisex)', description:'Dark wash denim, minor signs of wear. Waist: 32.', price:700, image:'https://picsum.photos/seed/jeans1/600/400', stock:4},
  {id:'p4', title:'Kids T-Shirt', description:'Cute printed tee for kids. Size: 6-8 yrs.', price:250, image:'https://picsum.photos/seed/kids1/600/400', stock:6}
];

const productsEl = document.getElementById('products');
const cartCount = document.getElementById('cart-count');
const modal = document.getElementById('modal');
const openCart = document.getElementById('open-cart');
const closeModal = document.getElementById('close-modal');
const cartItemsEl = document.getElementById('cart-items');
const cartTotalEl = document.getElementById('cart-total');
const placeOrderBtn = document.getElementById('place-order');
const orderResult = document.getElementById('order-result');

let cart = [];

function format(n){return n.toFixed(2);}

function renderProducts(){
  productsEl.innerHTML = '';
  PRODUCTS.forEach(p=>{
    const card = document.createElement('article');
    card.className='card';
    card.innerHTML = `<img src="${p.image}" alt="${p.title}" />
      <h4>${p.title}</h4>
      <p class="small">${p.description}</p>
      <div class="price-row">
        <div><strong>৳ ${format(p.price)}</strong><div class="small">স্টক: ${p.stock}</div></div>
        <button class="add-btn" data-id="${p.id}">Add</button>
      </div>`;
    productsEl.appendChild(card);
  });
  document.querySelectorAll('.add-btn').forEach(b=>b.addEventListener('click',()=>addToCart(b.dataset.id)));
}

function addToCart(id){
  const p = PRODUCTS.find(x=>x.id===id);
  const existing = cart.find(i=>i.id===id);
  if(existing){
    if(existing.qty < p.stock) existing.qty++;
  } else {
    cart.push({...p, qty:1});
  }
  updateCartUI();
}

function updateCartUI(){
  cartCount.textContent = cart.reduce((s,i)=>s+i.qty,0);
}

openCart.addEventListener('click',()=>{ showModal(); });
closeModal.addEventListener('click',()=>{ hideModal(); });

function showModal(){ renderCartItems(); modal.classList.remove('hidden'); }
function hideModal(){ modal.classList.add('hidden'); orderResult.style.display='none'; orderResult.textContent=''; }

function renderCartItems(){
  cartItemsEl.innerHTML='';
  if(cart.length===0){ cartItemsEl.innerHTML='<p class="small">তোমার কার্ট খালি।</p>'; cartTotalEl.textContent='0.00'; return; }
  cart.forEach(i=>{
    const row = document.createElement('div');
    row.className='cart-row';
    row.innerHTML = `<img src="${i.image}" alt="${i.title}"/>
      <div style="flex:1"><div><strong>${i.title}</strong></div><div class="small">৳ ${format(i.price)}</div></div>
      <div><input type="number" class="qty" min="1" value="${i.qty}" data-id="${i.id}" /></div>
      <div><button data-remove="${i.id}">Remove</button></div>`;
    cartItemsEl.appendChild(row);
  });
  // attach events
  cartItemsEl.querySelectorAll('.qty').forEach(inp=> inp.addEventListener('change', (e)=> {
    const id = e.target.dataset.id; const q = parseInt(e.target.value) || 1;
    const item = cart.find(x=>x.id===id); item.qty = Math.max(1, q); renderCartItems(); updateCartUI();
  }));
  cartItemsEl.querySelectorAll('[data-remove]').forEach(b=> b.addEventListener('click', ()=> {
    const id = b.getAttribute('data-remove'); cart = cart.filter(x=>x.id!==id); renderCartItems(); updateCartUI();
  }));
  cartTotalEl.textContent = format(cart.reduce((s,i)=>s + i.price * i.qty, 0));
}

placeOrderBtn.addEventListener('click', ()=>{
  const name = document.getElementById('name').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const address = document.getElementById('address').value.trim();
  const pm = document.querySelector('input[name="pm"]:checked').value;
  if(cart.length===0){ showMessage('তোমার কার্ট খালি — অর্ডার রাখো না।','error'); return; }
  if(!name || !phone){ showMessage('দয়া করে নাম ও মোবাইল নম্বর দাও।','error'); return; }
  // simulate payment
  showMessage('Processing payment...','ok');
  setTimeout(()=>{
    cart = []; renderCartItems(); updateCartUI();
    showMessage(pm==='bkash' ? 'bKash দিয়ে পেমেন্ট সফল হয়েছে।' : 'Card দিয়ে পেমেন্ট সফল হয়েছে।','ok');
  },1200);
});

function showMessage(msg, type){
  orderResult.textContent = msg;
  orderResult.style.display='block';
  if(type==='error'){ orderResult.classList.add('error'); } else { orderResult.classList.remove('error'); }
}

document.getElementById('year').textContent = new Date().getFullYear();
renderProducts();
